// ------------- cufon ----------------------

Cufon.replace('h3, .top-content li, .twitter p');
Cufon.replace('.cat li a, .links li a', {hover: 'true', textDecoration:'underline'});
Cufon.replace('h2.cufon-h2 span');

// ------------- jflickrfeed --------------

$(document).ready(function(){
	$('.flickr ul').jflickrfeed({
		flickrbase: 'http://api.flickr.com/services/feeds/',
		feedapi: 'photos_public.gne',
		qstrings: {
		        tags: 'color,pencil,crayon',
		    },
		limit: 6,
		cleanDescription: true,
		itemTemplate: '<li><a href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
	});
});

// ------------- twitterjs --------------

getTwitters('twitter', { 
			  id: 'tatygrassini', // Here's where you type your Twitter ID
			  count: 1, 
			  enableLinks: true, 
			  ignoreReplies: true, 
			  clearContents: true,

			  template: '<p><em>&ldquo;%text%&rdquo;</em></p> <p class="cufon"><a href="http://twitter.com/%user_screen_name%/statuses/%id%/">%time%</a> <br />From&nbsp;%source%</p> <h4><a href="http://twitter.com/%user_screen_name%/">Follow us on Twitter!</a></h4>',

				callback: function() {
		          Cufon.replace('p.cufon, h4'); // This hack helps styling Twitter texts with Cufón
		        }
			});